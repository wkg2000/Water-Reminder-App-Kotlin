package com.example.waterreminder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.waterreminder.R

class HistoryAdapter(
    private var historyList: List<Pair<String, Int>>,
    private val onItemClick: (String) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateText: TextView = itemView.findViewById(R.id.dateText)
        val countText: TextView = itemView.findViewById(R.id.countText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val (date, count) = historyList[position]
        holder.dateText.text = date
        holder.countText.text = "$count bottles"
        holder.itemView.setOnClickListener {
            onItemClick(date)
        }
    }

    override fun getItemCount() = historyList.size

    fun updateList(newList: List<Pair<String, Int>>) {
        historyList = newList
        notifyDataSetChanged()
    }
}
