package com.example.waterreminder

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import com.example.waterreminder.R

class MainActivity : AppCompatActivity() {

    private lateinit var intervalInput: EditText
    private lateinit var toggleButton: Button
    private lateinit var countdownText: TextView
    private lateinit var drinkButton: Button
    private lateinit var resetButton: Button
    private lateinit var waterCountText: TextView
    private lateinit var historyButton: Button
    private lateinit var dbHelper: WaterDatabaseHelper

    private var isAlarmSet = false
    private var countdownHandler: Handler? = null
    private var countdownRunnable: Runnable? = null
    private val dailyGoal = 12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }

        intervalInput = findViewById(R.id.intervalInput)
        toggleButton = findViewById(R.id.toggleButton)
        countdownText = findViewById(R.id.countdownText)
        drinkButton = findViewById(R.id.drinkButton)
        resetButton = findViewById(R.id.resetButton)
        waterCountText = findViewById(R.id.waterCountText)
        historyButton = findViewById(R.id.historyButton)

        dbHelper = WaterDatabaseHelper(this)

        val sharedPrefs = getSharedPreferences("water_reminder_prefs", MODE_PRIVATE)
        isAlarmSet = sharedPrefs.getBoolean("IS_ALARM_SET", false)
        val savedInterval = sharedPrefs.getLong("REMINDER_INTERVAL", 30)

        if (isAlarmSet) {
            intervalInput.setText(savedInterval.toString())
            toggleButton.text = getString(R.string.cancel_reminder)
            startCountdown(savedInterval)
        }

        updateWaterCount()

        toggleButton.setOnClickListener {
            val intervalStr = intervalInput.text.toString()
            if (intervalStr.isNotEmpty()) {
                val interval = intervalStr.toLong()
                if (!isAlarmSet) {
                    AlarmScheduler.scheduleAlarm(this, interval)
                    startCountdown(interval)
                    toggleButton.text = getString(R.string.cancel_reminder)
                    isAlarmSet = true

                    sharedPrefs.edit {
                        putBoolean("IS_ALARM_SET", true)
                        putLong("REMINDER_INTERVAL", interval)
                    }

                    Toast.makeText(this, "Reminder Set", Toast.LENGTH_SHORT).show()
                } else {
                    AlarmScheduler.cancelAlarm(this)
                    countdownText.text = ""
                    countdownHandler?.removeCallbacks(countdownRunnable ?: return@setOnClickListener)
                    toggleButton.text = getString(R.string.set_reminder)
                    isAlarmSet = false

                    sharedPrefs.edit {
                        putBoolean("IS_ALARM_SET", false)
                        remove("REMINDER_INTERVAL")
                    }

                    Toast.makeText(this, "Reminder Cancelled", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter interval in minutes", Toast.LENGTH_SHORT).show()
            }
        }

        drinkButton.setOnClickListener {
            dbHelper.addDrinkRecord()
            updateWaterCount()
            Toast.makeText(this, "Water bottle logged successfully!", Toast.LENGTH_SHORT).show()
        }

        resetButton.setOnClickListener {
            dbHelper.resetDrinkRecords()
            updateWaterCount()
            Toast.makeText(this, "Today's log has been reset.", Toast.LENGTH_SHORT).show()
        }


        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startCountdown(minutes: Long) {
        countdownHandler?.removeCallbacks(countdownRunnable ?: return)
        var timeLeft = minutes * 60
        countdownRunnable = object : Runnable {
            override fun run() {
                val mins = timeLeft / 60
                val secs = timeLeft % 60
                countdownText.text = getString(R.string.countdown_text, mins, secs)
                if (timeLeft > 0) {
                    timeLeft--
                    countdownHandler?.postDelayed(this, 1000)
                } else {
                    countdownText.text = ""
                }
            }
        }
        countdownHandler = Handler(Looper.getMainLooper())
        countdownHandler?.post(countdownRunnable!!)
    }

    private fun updateWaterCount() {
        val count = dbHelper.getTodayDrinkCount()
        waterCountText.text = getString(R.string.water_bottle_count, count, dailyGoal)
    }
}
