package com.example.waterreminder

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: WaterDatabaseHelper
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        dbHelper = WaterDatabaseHelper(this)

        val searchBar = findViewById<EditText>(R.id.searchBar)
        val recyclerView = findViewById<RecyclerView>(R.id.historyRecyclerView)
        val backButton = findViewById<Button>(R.id.backButton)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = HistoryAdapter(dbHelper.getAllDailyTotals()) { date ->
            showEditDeleteDialog(date)
        }
        recyclerView.adapter = adapter

        searchBar.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val searchText = s.toString()
                if (searchText.isEmpty()) {
                    adapter.updateList(dbHelper.getAllDailyTotals())
                } else {
                    adapter.updateList(dbHelper.searchDailyTotalByDate(searchText))
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        backButton.setOnClickListener {
            finish() // closes HistoryActivity and returns to MainActivity
        }
    }

    private fun showEditDeleteDialog(date: String) {
        val options = arrayOf("Edit Count", "Delete Day")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Manage $date")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showEditDialog(date)
                    1 -> {
                        dbHelper.deleteDailyTotal(date)
                        adapter.updateList(dbHelper.getAllDailyTotals())
                    }
                }
            }
            .show()
    }

    private fun showEditDialog(date: String) {
        val input = EditText(this)
        input.hint = "Enter new count"

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Edit Count for $date")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val newCount = input.text.toString().toIntOrNull()
                if (newCount != null && newCount >= 0) {
                    dbHelper.updateDailyTotal(date, newCount)
                    adapter.updateList(dbHelper.getAllDailyTotals())
                } else {
                    Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
