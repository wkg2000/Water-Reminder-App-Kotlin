package com.example.waterreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            try {
                // Check if alarm was previously set
                val sharedPrefs = context.getSharedPreferences("water_reminder_prefs", Context.MODE_PRIVATE)
                val isAlarmSet = sharedPrefs.getBoolean("IS_ALARM_SET", false)
                val savedInterval = sharedPrefs.getLong("REMINDER_INTERVAL", 30) // Default 30 minutes

                if (isAlarmSet) {
                    // Re-schedule the alarm after boot
                    AlarmScheduler.scheduleAlarm(context, savedInterval)
                    Log.i("BootReceiver", "Water reminder alarm re-scheduled after boot: $savedInterval minutes")
                }
            } catch (e: Exception) {
                Log.e("BootReceiver", "Error re-scheduling alarm after boot", e)
            }
        }
    }
}