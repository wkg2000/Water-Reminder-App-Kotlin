package com.example.waterreminder

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class WaterDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "water_db", null, 1) {

    companion object {
        const val TABLE_NAME = "water_log"
        const val COLUMN_ID = "id"
        const val COLUMN_TIMESTAMP = "timestamp"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TIMESTAMP INTEGER
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addDrinkRecord() {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TIMESTAMP, System.currentTimeMillis() / 1000)
        db.insert(TABLE_NAME, null, values)
    }

    fun getTodayDrinkCount(): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT COUNT(*) FROM $TABLE_NAME 
            WHERE DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) = DATE('now', 'localtime')
            """.trimIndent(), null
        )
        val count = if (cursor.moveToFirst()) cursor.getInt(0) else 0
        cursor.close()
        return count
    }

    fun resetDrinkRecords() {
        val db = writableDatabase
        db.execSQL(
            """
            DELETE FROM $TABLE_NAME 
            WHERE DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) = DATE('now', 'localtime')
            """.trimIndent()
        )
    }

    fun getAllDailyTotals(): List<Pair<String, Int>> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) as date, COUNT(*) as count
            FROM $TABLE_NAME
            GROUP BY date
            ORDER BY date DESC
            """.trimIndent(), null
        )
        val results = mutableListOf<Pair<String, Int>>()
        while (cursor.moveToNext()) {
            results.add(cursor.getString(0) to cursor.getInt(1))
        }
        cursor.close()
        return results
    }

    fun searchDailyTotalByDate(searchDate: String): List<Pair<String, Int>> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) as date, COUNT(*) as count
            FROM $TABLE_NAME
            WHERE DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) LIKE ?
            GROUP BY date
            ORDER BY date DESC
            """.trimIndent(),
            arrayOf("%$searchDate%")
        )
        val results = mutableListOf<Pair<String, Int>>()
        while (cursor.moveToNext()) {
            results.add(cursor.getString(0) to cursor.getInt(1))
        }
        cursor.close()
        return results
    }

    // ✅ Update the total for a specific date
    fun updateDailyTotal(date: String, newCount: Int) {
        val db = writableDatabase
        // Delete all records for that date
        db.execSQL(
            """
            DELETE FROM $TABLE_NAME 
            WHERE DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) = DATE(?, 'localtime')
            """.trimIndent(), arrayOf(date)
        )
        // Insert newCount records for that date
        repeat(newCount) {
            val values = ContentValues()
            // Store as timestamp for the selected date
            val customTimestamp = "$date 12:00:00" // midday to avoid timezone issues
            val cursor = db.rawQuery("SELECT strftime('%s', ?)", arrayOf(customTimestamp))
            if (cursor.moveToFirst()) {
                values.put(COLUMN_TIMESTAMP, cursor.getLong(0))
            }
            cursor.close()
            db.insert(TABLE_NAME, null, values)
        }
    }

    // ✅ Delete all records for a specific date
    fun deleteDailyTotal(date: String) {
        val db = writableDatabase
        db.execSQL(
            """
            DELETE FROM $TABLE_NAME 
            WHERE DATE(datetime($COLUMN_TIMESTAMP, 'unixepoch', 'localtime')) = DATE(?, 'localtime')
            """.trimIndent(), arrayOf(date)
        )
    }
}
