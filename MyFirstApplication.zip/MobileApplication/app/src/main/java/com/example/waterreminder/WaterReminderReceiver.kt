package com.example.waterreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class WaterReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            // Show a notification when the alarm fires
            NotificationHelper.showNotification(
                context,
                "Time to Drink Water",
                "Stay hydrated! Have a glass of water now."
            )
        } catch (e: Exception) {
            Log.e("WaterReminderReceiver", "Error showing notification", e)
        }
    }
}